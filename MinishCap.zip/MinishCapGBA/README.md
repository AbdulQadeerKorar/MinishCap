# The Minish Cap – stylized touch player (GBA, mGBA core)
Upload MinishCap.zip to a GitHub repo root + .github/workflows/build.yml, run "Build Minish Cap APK",
download artifact MinishCap-apk, install, pick your own .gba dump.
Menu (top centre): save/load state, settings (color correction, frame blending, audio filter, swap buttons,
pad opacity, haptics, fast-forward, mute), cheats, restart, change ROM.
