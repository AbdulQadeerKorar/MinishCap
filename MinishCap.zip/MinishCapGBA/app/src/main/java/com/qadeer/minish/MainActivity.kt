package com.qadeer.minish

import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private class Opt(val label: String, val key: String, val names: List<String>, val values: List<String>)

private val OPTS = listOf(
    Opt("Color correction", "mgba_color_correction", listOf("Off", "GBA screen look", "Auto"), listOf("OFF", "GBA", "Auto")),
    Opt("Frame blending", "mgba_interframe_blending", listOf("Off", "Mix (less flicker)", "LCD ghosting"), listOf("OFF", "mix", "lcd_ghosting")),
    Opt("Audio low-pass filter", "mgba_audio_low_pass_filter", listOf("Off", "On"), listOf("disabled", "enabled"))
)

private class Cheat(var name: String, var code: String, var on: Boolean)

class MainActivity : ComponentActivity() {

    private lateinit var root: FrameLayout
    private lateinit var pad: ForestPad
    private lateinit var splash: TextView
    private lateinit var prefs: SharedPreferences
    private var retro: GLRetroView? = null
    private var romKey = ""
    private var fastForward = 1
    private var muted = false
    private val handler = Handler(Looper.getMainLooper())
    private val autosave = object : Runnable {
        override fun run() { saveSram(); handler.postDelayed(this, 30_000) }
    }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val changing = retro != null
            if (changing) saveSram()
            prefs.edit().putString("rom", uri.toString()).apply()
            if (changing) recreate() else startGame(uri)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val pale = Color.parseColor("#E8DEAA")

    // ------------------------------------------------------------ reflection helpers
    private fun callMethod(target: Any, name: String, vararg args: Any?): Boolean = try {
        val m = target.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == args.size }
        if (m == null) false else { m.invoke(target, *args); true }
    } catch (e: Exception) { false }

    private fun varsArray(pairs: List<Pair<String, String>>): Any? = try {
        val cls = Class.forName("com.swordfish.libretrodroid.Variable")
        val ctor = cls.getConstructor(String::class.java, String::class.java)
        val arr = java.lang.reflect.Array.newInstance(cls, pairs.size)
        pairs.forEachIndexed { i, kv -> java.lang.reflect.Array.set(arr, i, ctor.newInstance(kv.first, kv.second)) }
        arr
    } catch (e: Exception) { null }

    private fun pushVar(key: String, value: String) {
        val r = retro ?: return
        val arr = varsArray(listOf(key to value)) ?: return
        try { r.javaClass.methods.firstOrNull { it.name == "updateVariables" }?.invoke(r, arr) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------- lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("minish", MODE_PRIVATE)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#020504")) }

        pad = ForestPad(this).apply {
            swapAB = prefs.getBoolean("swap", false)
            haptics = prefs.getBoolean("haptics", true)
            alpha = prefs.getInt("alpha", 100) / 100f
            listener = ForestPad.KeyListener { k, down ->
                retro?.sendKeyEvent(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, k)
            }
        }
        root.addView(pad, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        splash = TextView(this).apply {
            text = "◆  THE MINISH CAP  ◆\n\nTap to choose your .gba ROM"
            gravity = Gravity.CENTER
            setTextColor(pale)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            letterSpacing = 0.12f
            typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
            setOnClickListener { picker.launch(arrayOf("*/*")) }
        }
        root.addView(splash, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.CENTER))

        val menu = TextView(this).apply {
            text = "☰"
            setTextColor(pale)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            setPadding(dp(16), dp(6), dp(16), dp(6))
            alpha = 0.6f
            setOnClickListener { showMenu() }
        }
        root.addView(menu, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(10) })

        setContentView(root)
        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> layoutGame(r - l, b - t) }

        prefs.getString("rom", null)?.let { startGame(Uri.parse(it)) }
    }

    private fun layoutGame(w: Int, h: Int) {
        val v = retro ?: return
        val lp = v.layoutParams as FrameLayout.LayoutParams
        val wantH = if (h > w) w * 2 / 3 else MATCH_PARENT
        if (lp.height != wantH || lp.width != MATCH_PARENT) {
            lp.width = MATCH_PARENT; lp.height = wantH; lp.gravity = Gravity.TOP
            v.post { v.layoutParams = lp }
        }
    }

    private fun optIdx(o: Opt) = o.values.indexOf(prefs.getString("opt_${o.key}", o.values[0])).coerceAtLeast(0)

    private fun startGame(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            romKey = uri.toString().hashCode().toString()
            val sram = File(filesDir, "sram_$romKey.bin")
            val data = GLRetroViewData(this).apply {
                coreFilePath = "libmgba_libretro_android.so"
                gameFileBytes = bytes
                systemDirectory = filesDir.absolutePath
                savesDirectory = File(filesDir, "saves").apply { mkdirs() }.absolutePath
                if (sram.exists()) saveRAMState = sram.readBytes()
                preferLowLatencyAudio = true
            }
            val startVars = OPTS.map { it.key to it.values[optIdx(it)] }
            val arr = varsArray(startVars)
            if (arr != null) {
                try { data.javaClass.methods.firstOrNull { it.name == "setVariables" }?.invoke(data, arr) } catch (_: Exception) {}
            }
            val v = GLRetroView(this, data)
            lifecycle.addObserver(v)
            retro = v
            root.addView(v, 0, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT, Gravity.TOP))
            splash.visibility = View.GONE
            layoutGame(root.width, root.height)
            handler.postDelayed(autosave, 30_000)
            handler.postDelayed({ applyAllCheats() }, 2000)
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't open ROM: ${e.message}", Toast.LENGTH_LONG).show()
            prefs.edit().remove("rom").apply()
            splash.visibility = View.VISIBLE
        }
    }

    private fun saveSram() {
        val r = retro ?: return
        try { File(filesDir, "sram_$romKey.bin").writeBytes(r.serializeSRAM()) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------------ menus
    private fun showMenu() {
        AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(arrayOf("💾 Save state", "📂 Load state", "⚙ Settings", "🎯 Cheats", "🔄 Restart game", "📁 Change ROM")) { _, i ->
                when (i) {
                    0 -> retro?.let {
                        File(filesDir, "state_$romKey.bin").writeBytes(it.serializeState())
                        Toast.makeText(this, "State saved", Toast.LENGTH_SHORT).show()
                    }
                    1 -> retro?.let {
                        val f = File(filesDir, "state_$romKey.bin")
                        if (f.exists()) { it.unserializeState(f.readBytes()); Toast.makeText(this, "State loaded", Toast.LENGTH_SHORT).show() }
                        else Toast.makeText(this, "No saved state yet", Toast.LENGTH_SHORT).show()
                    }
                    2 -> showSettings()
                    3 -> showCheats()
                    4 -> { saveSram(); recreate() }
                    5 -> picker.launch(arrayOf("*/*"))
                }
            }.show()
    }

    private fun showSettings() {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        for (o in OPTS) {
            labels.add("${o.label}: ${o.names[optIdx(o)]}")
            acts.add { chooseOpt(o) }
        }
        labels.add("Swap jump/attack-side buttons (now: ${if (pad.swapAB) "swapped" else "default"})")
        acts.add {
            pad.swapAB = !pad.swapAB
            prefs.edit().putBoolean("swap", pad.swapAB).apply(); pad.invalidate(); showSettings()
        }
        labels.add("Pad opacity: ${(pad.alpha * 100).toInt()}%")
        acts.add {
            val next = when (prefs.getInt("alpha", 100)) { 100 -> 80; 80 -> 60; 60 -> 40; else -> 100 }
            prefs.edit().putInt("alpha", next).apply(); pad.alpha = next / 100f; showSettings()
        }
        labels.add("Haptics: ${if (pad.haptics) "on" else "off"}")
        acts.add {
            pad.haptics = !pad.haptics
            prefs.edit().putBoolean("haptics", pad.haptics).apply(); showSettings()
        }
        labels.add("Fast-forward: ${fastForward}x")
        acts.add {
            fastForward = when (fastForward) { 1 -> 2; 2 -> 4; else -> 1 }
            val ok = retro?.let { callMethod(it, "setFrameSpeed", fastForward) } ?: false
            if (!ok) Toast.makeText(this, "Fast-forward not supported by this LibretroDroid version", Toast.LENGTH_LONG).show()
            showSettings()
        }
        labels.add("Sound: ${if (muted) "muted" else "on"}")
        acts.add {
            muted = !muted
            val ok = retro?.let { callMethod(it, "setAudioEnabled", !muted) } ?: false
            if (!ok) Toast.makeText(this, "Mute not supported by this LibretroDroid version", Toast.LENGTH_LONG).show()
            showSettings()
        }
        labels.add("Widescreen: not possible on GBA (fixed 3:2 screen)")
        acts.add { Toast.makeText(this, "GBA games render at a fixed 240x160, so there is no real widescreen mode.", Toast.LENGTH_LONG).show() }

        AlertDialog.Builder(this).setTitle("Settings")
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
            .setNegativeButton("Close", null).show()
    }

    private fun chooseOpt(o: Opt) {
        AlertDialog.Builder(this).setTitle(o.label)
            .setSingleChoiceItems(o.names.toTypedArray(), optIdx(o)) { d, which ->
                prefs.edit().putString("opt_${o.key}", o.values[which]).apply()
                pushVar(o.key, o.values[which])
                d.dismiss(); showSettings()
            }.show()
    }

    // ------------------------------------------------------------------------ cheats
    private fun loadCheats(): MutableList<Cheat> {
        val out = ArrayList<Cheat>()
        try {
            val arr = JSONArray(prefs.getString("cheats_$romKey", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Cheat(o.getString("n"), o.getString("c"), o.getBoolean("e")))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun saveCheats(list: List<Cheat>) {
        val arr = JSONArray()
        for (c in list) arr.put(JSONObject().put("n", c.name).put("c", c.code).put("e", c.on))
        prefs.edit().putString("cheats_$romKey", arr.toString()).apply()
    }

    private fun applyCheat(index: Int, c: Cheat): Boolean {
        val r = retro ?: return false
        val code = c.code.trim().lines().filter { it.isNotBlank() }.joinToString("+") { it.trim() }
        return callMethod(r, "setCheat", index, c.on, code)
    }

    private fun applyAllCheats() {
        val list = loadCheats()
        list.forEachIndexed { i, c -> if (c.on) applyCheat(i, c) }
    }

    private fun showCheats() {
        val list = loadCheats()
        val names = list.map { it.name }.toTypedArray()
        val checked = BooleanArray(list.size) { list[it].on }
        AlertDialog.Builder(this).setTitle("Cheats (GameShark / Action Replay)")
            .setMultiChoiceItems(names, checked) { _, i, on ->
                list[i].on = on
                saveCheats(list)
                if (!applyCheat(i, list[i])) Toast.makeText(this, "Cheats not supported by this LibretroDroid version", Toast.LENGTH_LONG).show()
            }
            .setPositiveButton("Add") { _, _ -> addCheat() }
            .setNeutralButton("Delete") { _, _ -> deleteCheat() }
            .setNegativeButton("Close", null).show()
    }

    private fun addCheat() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Name (e.g. Infinite hearts)" }
        val code = EditText(this).apply {
            hint = "Code, one line per entry"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            minLines = 3
        }
        box.addView(name); box.addView(code)
        AlertDialog.Builder(this).setTitle("Add cheat").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val n = name.text.toString().trim(); val c = code.text.toString().trim()
                if (n.isNotEmpty() && c.isNotEmpty()) {
                    val list = loadCheats(); list.add(Cheat(n, c, false)); saveCheats(list)
                }
                showCheats()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun deleteCheat() {
        val list = loadCheats()
        if (list.isEmpty()) { Toast.makeText(this, "No cheats to delete", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Delete which cheat?")
            .setItems(list.map { it.name }.toTypedArray()) { _, i ->
                val c = list[i]
                if (c.on) { c.on = false; applyCheat(i, c) }
                list.removeAt(i); saveCheats(list); showCheats()
            }.show()
    }

    override fun onResume() { super.onResume(); if (retro != null) { handler.removeCallbacks(autosave); handler.postDelayed(autosave, 30_000) } }
    override fun onPause() { saveSram(); handler.removeCallbacks(autosave); super.onPause() }
    override fun onStop() { saveSram(); super.onStop() }
}
